/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package my_first;

/**
 *
 * @author tsl
 */
public interface Displayable {
    String company = "ABC";
    String fax = "012345";
    public void Displayalldetails();
    public void Displayearnings();
    
}
